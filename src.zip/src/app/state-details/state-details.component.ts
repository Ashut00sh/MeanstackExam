import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-state-details',
  templateUrl: './state-details.component.html',
  styleUrls: ['./state-details.component.css']
})
export class StateDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
