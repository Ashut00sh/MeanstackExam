import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';

import { } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public myformgroup = new FormGroup({
    username: new FormControl('', [
      Validators.required,
Validators.pattern('[a-z0-9@]*'),
Validators.pattern('[a-z0-9@]*'),
 ]),
 vrnum: new FormControl('', [
  Validators.required,
  Validators.pattern('[A-Z0-9-]*'),
]),
password: new FormControl('', [
  Validators.required,
  Validators.pattern('[a-z0-9@]*'),
]),
});







  constructor(private router: Router) { }
  ngOnInit(): void {


    if (!sessionStorage.getItem('sid'))
    {
      this.router.navigate(['Home']);
    }
  }



  LoginHere()
  {

    this.router.navigate(['Home']);
  }
  public readvalue() {
    const data = this.myformgroup.value;
    this.myformgroup.reset();

  }
}


